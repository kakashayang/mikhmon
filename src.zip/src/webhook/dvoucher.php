Rasendria*
Rnet-Fam|360 Hari|75000|100000|360d|Rasendria|3M/3M*
Rnet3H|3 Jam|1000|2000|3h|Rasendria|3M/3M*
Rnet6H|6 Jam|2000|3000|6h|Rasendria|3M/3M*
Rnet12H|12 Jam|3000|4000|12h|Rasendria|3M/3M*
Rnet1D|1 Hari|4000|5000|1d|Rasendria|3M/3M*
Rnet3D|3 Hari|6000|7000|3d|Rasendria|3M/3M*
Rnet7D|7 Hari|8000|9000|7d|Rasendria|3M/3M*
RnetTv|30 Hari|24000|25000|30d|Rasendria|5M/5M*
Silver|30 Hari|75000|100000|30d|Rasendria|5M/5M*
Gold|30 Hari|100000|125000|30d|Rasendria|6M/6M*
Platinum|30 Hari|125000|150000|30d|Rasendria|7M/7M*
RnetAdm|360 Hari|100000|100000|360d|Rasendria|20M/60M*
Rnet-Tv|360 Hari|25000|25000|360d|Rasendria|5M/5M#

